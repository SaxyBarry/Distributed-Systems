# Download and install ZeroMQ for Python
pip install pyzmq

# Run webserver.py and testing.py concurrently
python webserver.py &
python testing.py &